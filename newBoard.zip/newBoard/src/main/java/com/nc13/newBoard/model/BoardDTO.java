package com.nc13.newBoard.model;

import lombok.Data;

import java.util.Date;

@Data
public class BoardDTO {
    private int id;
    private String nickname;
    private String title;
    private String content;
    private Date entryDate;
    private Date modifyDate;
    private int writerId;
}
