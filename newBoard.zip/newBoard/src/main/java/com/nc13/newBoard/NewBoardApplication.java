package com.nc13.newBoard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewBoardApplication.class, args);
	}

}
