package com.nc13.newBoard.controller;

import com.nc13.newBoard.model.BoardDTO;
import com.nc13.newBoard.model.UserDTO;
import com.nc13.newBoard.service.BoardService;
import jakarta.servlet.http.HttpSession;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/board/")
public class BoardController {
    @Autowired
    private BoardService boardService;

    @GetMapping("showAll")
    public String moveToFirstPage() {
        return "redirect:/board/showAll/1";
    }

    @GetMapping("showAll/{pageNo}")
    public String showAll(Model model, HttpSession session, @PathVariable int pageNo) {
        UserDTO logIn = (UserDTO) session.getAttribute("logIn");
        if (logIn == null) {
            return "redirect:/";
        }
        int maxPage = boardService.selectMaxPage();

        int startPage;
        int endPage;

        if (maxPage < 5) {
            startPage = 1;
            endPage = maxPage;
        } else if (pageNo <= 3) {
            startPage = 1;
            endPage = 5;
        } else if (pageNo >= maxPage - 2) {
            startPage = maxPage - 4;
            endPage = maxPage;
        } else {
            startPage = pageNo - 2;
            endPage = pageNo + 2;
        }

        model.addAttribute("curPage", pageNo);
        model.addAttribute("startPage", startPage);
        model.addAttribute("endPage", endPage);

        List<BoardDTO> list = boardService.selectAll(pageNo);
        model.addAttribute("list", list);

        return "board/showAll";
    }

    @GetMapping("write")
    public String write(HttpSession session) {
        UserDTO logIn = (UserDTO) session.getAttribute("logIn");
        if (logIn == null) {
            return "redirect:/";
        }
        return "board/write";
    }

    @PostMapping("write")
    public String write(HttpSession session, BoardDTO boardDTO) {
        UserDTO logIn = (UserDTO) session.getAttribute("logIn");
        if (logIn == null) {
            return "redirect:/";
        }
        boardDTO.setWriterId(logIn.getId());
        boardService.insert(boardDTO);
        return "redirect:/board/showAll";
    }

    @GetMapping("showOne/{id}")
    public String showOne(HttpSession session, @PathVariable int id, Model model, RedirectAttributes redirectAttributes) {
        UserDTO logIn = (UserDTO) session.getAttribute("logIn");
        if (logIn == null) {
            return "redirect:/";
        }

        BoardDTO boardDTO = boardService.selectOne(id);
        if (boardDTO == null) {
            redirectAttributes.addFlashAttribute("message", "해당 글은 존재하지 않는 글입니다.");
            return "redirect:/showMessage";
        }

        model.addAttribute("boardDTO", boardDTO);
        return "board/showOne";
    }

    @GetMapping("update/{id}")
    public String update(HttpSession session, @PathVariable int id, Model model, RedirectAttributes redirectAttributes) {
        UserDTO logIn = (UserDTO) session.getAttribute("logIn");
        if (logIn == null) {
            return "redirect:/";
        }
        BoardDTO boardDTO = boardService.selectOne(id);
        if (boardDTO.getWriterId() != logIn.getId()) {
            redirectAttributes.addFlashAttribute("message", "권한이 없습니다.");
            return "redirect:/showMessage";
        }
        model.addAttribute("boardDTO", boardDTO);
        return "board/update";
    }

    @PostMapping("update/{id}")
    public String update(HttpSession session, BoardDTO attempt, RedirectAttributes redirectAttributes, @PathVariable int id){
        UserDTO logIn = (UserDTO) session.getAttribute("logIn");
        if(logIn ==null){
            return "redirect:/";
        }

        BoardDTO boardDTO = boardService.selectOne(id);
        if(boardDTO ==null){
            redirectAttributes.addFlashAttribute("message","해당 글이 유효하지 않습니다.");
            return "redirect:/showMessage";
        }
        if (boardDTO.getWriterId() != logIn.getId()){
            redirectAttributes.addFlashAttribute("message", "권한이 없습니다.");
            return "redirect:/showMessage";
        }

        boardService.update(attempt);
        return "redirect:/board/showAll";
    }
@GetMapping("delete/{id}")
     public String delete(@PathVariable int id, RedirectAttributes redirectAttributes, HttpSession session){
    UserDTO logIn = (UserDTO) session.getAttribute("logIn");
    if(logIn == null){
        return "redirect:/";
    }
    BoardDTO boardDTO = boardService.selectOne(id);

    if(boardDTO == null){
        redirectAttributes.addFlashAttribute("message", "유효하지 않은 글입니다.");
        return "redirect:/showMessage";
    }
    if(boardDTO.getWriterId() != logIn.getId()){

        redirectAttributes.addFlashAttribute("message", "권한이 없습니다.");
        return "redirect:/showMessage";
    }
    boardService.delete(id);
    return "redirect:/board/showAll";
    }
}