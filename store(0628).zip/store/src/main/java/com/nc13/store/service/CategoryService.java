package com.nc13.store.service;


import com.nc13.store.model.CategoryDTO;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CategoryService {
    @Autowired
    private final SqlSession SESSION;
    private final String NAMESPACE = "com.nc13.mappers.CategoryMapper";


    public CategoryDTO show (CategoryDTO attempt){
        return SESSION.selectOne(NAMESPACE + ".show", attempt);
    }
}
