package com.nc13.store.model;

import lombok.Data;

@Data
public class CategoryDTO {
    private final int id;
    private final String top;
    private final String bottom;
    private final String acc;
    private final String homeWear;
}
