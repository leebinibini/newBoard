package com.nc13.store.service;

import com.nc13.store.model.ProductDTO;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.stream.events.Namespace;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductService {

    @Autowired
    private final SqlSession SESSION;

    private final String NAMESPACE = "com.nc13.mappers.ProductMapper";

    public ProductDTO selectAll(ProductDTO productDTO){

        return SESSION.selectOne(NAMESPACE+ ".selectAll", productDTO);
    }


}
