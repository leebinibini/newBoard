package com.nc13.store.controller;


import com.nc13.store.model.UserDTO;
import com.nc13.store.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/user/")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("auth")
    public String showAuth() {
        return "user/logIn";
    }

    @PostMapping("auth")
    public String auth(UserDTO userDTO, HttpSession session) {
        UserDTO result = userService.auth(userDTO);
        if (result != null && result.getGrade() == 1) {
            session.setAttribute("logIn", result);
            return "redirect:/product/showAll";
        } else if (result != null && result.getGrade() == 2) {
            session.setAttribute("logIn", result);
            return "redirect:/product.showAllSeller";
        } else if (result != null && result.getGrade() == 3) {
            session.setAttribute("logIn", result);
            return "redirect:/product/showAll";
        }
        return "redirect:/";
    }

    @GetMapping("register")
    public String showRegister() {
        return "user/register";
    }


    @PostMapping("register")
    public String register(UserDTO userDTO, RedirectAttributes redirectAttributes) {
        if (userService.validateUsername(userDTO.getUsername())) {
            userService.register(userDTO);
            System.out.println("회원가입 성공!");

        } else {
            redirectAttributes.addFlashAttribute("message", "중복된 아이디로는 회원가입을 할 수 없습니다.");
            return "redirect:/showMessage";
        }
        return "redirect:/";
    }

    @GetMapping("logOut/")
    public String logOut(HttpSession session) {
        UserDTO logIn = (UserDTO) session.getAttribute("logIn");
        if (logIn == null) {
            return "redirect:/";
        }
        session.removeAttribute("logIn");
        return "redirect:/";
    }

    @GetMapping("myPage/")
    public String myPage(HttpSession session) {
        UserDTO logIn = (UserDTO) session.getAttribute("logIn");
        if (logIn == null) {
            return "redirect:/";
        }

        return "user/myPage";
    }

}
