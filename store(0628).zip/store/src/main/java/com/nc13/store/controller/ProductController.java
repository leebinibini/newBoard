package com.nc13.store.controller;

import com.nc13.store.model.ProductDTO;
import com.nc13.store.service.ProductService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/product/")
public class ProductController {
    @Autowired
    public ProductService productService;

    @GetMapping("showAll")
   public String moveToShowAll (ProductDTO productDTO, Model model){
        productService.selectAll(productDTO);
        model.addAttribute("productDTO", productDTO);

        return "product/showAll";
    }

    @PostMapping("showAll")
    public String showAll(HttpSession session, ProductDTO productDTO){
        productService.selectAll(productDTO);
        return "product/showAll";
   }
//
//    @GetMapping("top")
//    public String showTop(HttpSession session, )
}
