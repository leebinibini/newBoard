package com.nc13.store.model;

import lombok.Data;

@Data
public class ProductDTO {
    private int id;
    private String name;
    private String information;
    private String imageUrl;
    private double price;
    private String category_id;
}
